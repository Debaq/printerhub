# 🖨️ PrinterHub Frontend

Sistema web moderno para gestión y monitoreo de impresoras 3D en tiempo real.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Status](https://img.shields.io/badge/status-production--ready-green)
![License](https://img.shields.io/badge/license-MIT-blue)

## ✨ Características

- 🎯 **Dashboard en tiempo real** con auto-refresh inteligente
- 🎮 **Control completo** de impresoras (temperatura, velocidad, gcode)
- 📁 **Gestión de archivos** gcode con upload y descarga
- 📊 **Estadísticas detalladas** y reportes personalizables
- 👑 **Panel de administración** completo
- 🔐 **Autenticación segura** con roles y permisos
- 📱 **Totalmente responsive** (mobile, tablet, desktop)
- 🎨 **Diseño moderno** con efectos visuales y animaciones
- ♿ **Accesible** (WCAG 2.1)

## 🚀 Quick Start

```bash
# 1. Clonar o descargar el proyecto
git clone https://github.com/tu-repo/printerhub-frontend

# 2. Copiar archivos a tu servidor web
cp -r printerhub-frontend/* /var/www/html/

# 3. Configurar API URL en js/config.js
nano js/config.js
# Cambiar API_URL a tu backend

# 4. Acceder desde el navegador
http://tu-servidor/
```

## 📂 Estructura

```
printerhub-frontend/
├── index.html              # Landing page público
│
├── pages/                  # Páginas de la aplicación
│   ├── login.html          # Página de login
│   ├── register.html       # Registro de usuarios
│   ├── dashboard.html      # Dashboard principal
│   ├── files.html          # Gestión de archivos
│   ├── statistics.html     # Estadísticas y reportes
│   └── admin.html          # Panel de administración
│
├── styles/                 # CSS (93 KB)
│   ├── variables.css       # Colores y variables
│   ├── reset.css           # Normalización
│   ├── main.css            # Componentes base
│   ├── login.css           # Autenticación
│   ├── dashboard.css       # Dashboard
│   ├── printers.css        # Tarjetas de impresoras
│   ├── modal.css           # Modales
│   ├── admin.css           # Panel admin
│   └── responsive.css      # Media queries
│
└── js/                     # JavaScript (137 KB)
    ├── config.js           # Configuración
    ├── utils.js            # Utilidades
    ├── api.js              # Cliente API REST
    ├── auth.js             # Autenticación
    ├── notifications.js    # Sistema de notificaciones
    ├── printers.js         # Gestor de impresoras
    ├── printer-modal.js    # Modal de control
    ├── files.js            # Gestor de archivos
    ├── statistics.js       # Estadísticas
    ├── admin.js            # Panel admin
    └── app.js              # Inicialización
```

## 🎨 Screenshots

### Dashboard
Monitoreo en tiempo real de todas las impresoras con filtros y búsqueda.

### Control de Impresora
Modal completo con temperaturas, velocidad, progreso y controles.

### Gestión de Archivos
Upload, descarga y envío de archivos gcode a impresoras.

### Panel Admin
Gestión completa de usuarios, impresoras, grupos y configuración.

## 🔧 Configuración

### API URL
Editar `js/config.js`:
```javascript
const CONFIG = {
  API_URL: '/api',  // Cambiar según tu backend
  // ...
};
```

### Intervalos de actualización
```javascript
REFRESH_INTERVAL: 5000,        // 5 segundos (normal)
REFRESH_INTERVAL_FAST: 2000,   // 2 segundos (imprimiendo)
```

### Colores
Editar `styles/variables.css`:
```css
:root {
  --primary: #9333ea;     /* Púrpura */
  --secondary: #ec4899;   /* Rosa */
  --accent: #06b6d4;      /* Cyan */
}
```

## 📡 API Endpoints

El frontend se comunica con estos endpoints:

### Autenticación
- `POST /api/auth.php?action=login`
- `POST /api/auth.php?action=register`
- `GET /api/auth.php?action=check_session`

### Impresoras
- `GET /api/printers.php?action=list`
- `GET /api/printers.php?action=get&id={id}`

### Comandos
- `POST /api/commands.php?action=pause`
- `POST /api/commands.php?action=resume`
- `POST /api/commands.php?action=cancel`

### Archivos
- `POST /api/files.php?action=upload`
- `GET /api/files.php?action=list`

Ver documentación completa en `PROYECTO_COMPLETO.md`

## 🌐 Compatibilidad

### Navegadores
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Dispositivos
- Desktop (1920x1080+)
- Laptop (1366x768+)
- Tablet (768x1024)
- Mobile (375x667+)

## 🐛 Debug Mode

Activar en `js/config.js`:
```javascript
DEBUG: true
```

Usar helpers en consola:
```javascript
debug.auth.getUser()
debug.api.getPrinters()
debug.notifications.success("Test")
```

## 🔒 Seguridad

### Implementado
- XSS Protection
- Token-based authentication
- Session management
- Input validation
- Secure localStorage

### Recomendaciones
- Usar HTTPS en producción
- Implementar rate limiting
- CSRF protection
- Content Security Policy

## 📦 Dependencias

**Ninguna!** 100% Vanilla JavaScript:
- ❌ No jQuery
- ❌ No frameworks (React/Vue/Angular)
- ❌ No Bootstrap
- ❌ No build tools

Solo navegador moderno y servidor web.

## 📈 Performance

- First Paint: < 1s
- Time to Interactive: < 2s
- Total Size: 271 KB (sin comprimir)
- ~20 HTTP requests (carga inicial)

## 🛠️ Desarrollo

### Estructura del código
- Modular y escalable
- Separación de responsabilidades
- Comentarios en español
- Nombres descriptivos

### Testing
```javascript
// En consola del navegador
debug.api.getPrinters().then(console.log)
debug.notifications.success("Test")
```

## 🚀 Deploy

### Apache
```bash
cp -r * /var/www/html/
systemctl restart apache2
```

### Nginx
```bash
cp -r * /usr/share/nginx/html/
systemctl restart nginx
```

### Docker (opcional)
```dockerfile
FROM nginx:alpine
COPY . /usr/share/nginx/html/
```

## 📚 Documentación

- `PROYECTO_COMPLETO.md` - Documentación completa del proyecto
- `ESTILOS_CSS_COMPLETADOS.md` - Guía de estilos CSS
- `JAVASCRIPT_COMPLETADO.md` - Guía de JavaScript
- Comentarios inline en cada archivo

## 🤝 Contribuir

Las contribuciones son bienvenidas! Por favor:

1. Fork el proyecto
2. Crea una rama (`git checkout -b feature/amazing`)
3. Commit cambios (`git commit -m 'Add amazing feature'`)
4. Push a la rama (`git push origin feature/amazing`)
5. Abre un Pull Request

## 📝 Licencia

Este proyecto está bajo la licencia MIT.

## 👨‍💻 Autor

Desarrollado con ❤️ para la gestión eficiente de impresoras 3D.

## 🙏 Agradecimientos

- Comunidad de impresión 3D
- OctoPrint como inspiración
- Usuarios beta testers

## 📞 Soporte

- 📧 Email: soporte@printerhub.com
- 📖 Docs: docs.printerhub.com
- 🐛 Issues: github.com/tu-repo/issues

---

**PrinterHub v1.0.0** - Sistema profesional de gestión de impresoras 3D 🖨️✨
