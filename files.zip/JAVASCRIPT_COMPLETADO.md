# PrinterHub Frontend - JavaScript Completado ✅

## Archivos JavaScript Creados (137 KB total)

### 1. **config.js** (2.8 KB)
Configuración global de la aplicación:
- URLs de API
- Intervalos de actualización (5s normal, 2s rápido)
- Claves de localStorage
- Estados de impresora y sus iconos
- Roles de usuario
- Límites de archivos (100 MB)
- Feature flags
- Constantes y configuraciones inmutables

### 2. **utils.js** (8.5 KB)
Utilidades generales reutilizables:
- Formateo de bytes, temperatura, tiempo
- Formateo de fechas (absoluto y relativo)
- Validaciones (email, password, username)
- Cálculo de fuerza de contraseña
- Escape HTML y truncado de texto
- Debounce y throttle
- Copiar al portapapeles
- Detección de móvil y estado online
- Logging condicional (debug mode)

### 3. **api.js** (11 KB)
Cliente completo para la API REST:
- Request genérico con manejo de tokens
- Métodos HTTP: GET, POST, PUT, DELETE
- Upload de archivos con FormData
- **Auth endpoints**: login, register, logout, check_session
- **Printers endpoints**: list, get, create, update, delete, update_notes, update_tags
- **Commands endpoints**: pause, resume, cancel, emergency_stop, home, setTemperature, setSpeed, sendCustomGcode
- **Files endpoints**: upload, list, delete, sendToPrinter, setPrivacy, download
- **Statistics endpoints**: overview, printerStats, usageReport, jobsHistory, filamentUsage
- **Users endpoints** (admin): list, get, create, update, delete, toggleBlock, assignPrinters
- **Groups endpoints** (admin): list, get, create, update, delete, addUsers, removeUser

### 4. **auth.js** (9.4 KB)
Sistema de autenticación y gestión de sesión:
- Manejo de tokens en localStorage
- Gestión de datos de usuario
- Métodos: login, register, logout
- Verificación de sesión (checkSession)
- Protección de páginas (requireAuth, requireAdmin)
- Redirección según rol
- Auto-verificación periódica (cada 1 minuto)
- Inicialización de UI (avatar, username)
- Validación de formularios
- Helpers para permisos (isAdmin, canPrintPrivate)

### 5. **notifications.js** (7.5 KB)
Sistema de notificaciones toast:
- Notificaciones tipo: success, error, warning, info
- Auto-cierre configurable
- Notificaciones persistentes
- Loading spinners
- Actualización de notificaciones existentes
- Confirmaciones con Promise
- Prompts para input
- Helpers para errores de API
- Animaciones de entrada/salida

### 6. **printers.js** (15 KB)
Gestor principal de impresoras:
- Carga y renderizado de impresoras
- Filtrado por estado (all, printing, idle, offline, error)
- Búsqueda por nombre y tags
- Vista grid y lista
- Auto-refresh cada 5 segundos
- Pausa de refresh cuando tab no está visible
- Manejo de acciones: pause, resume, cancel, refresh
- Cards con:
  - Estado y badge animado
  - Progreso de impresión
  - Temperaturas (hotend y cama)
  - Tiempo restante
  - Tags
  - Controles
- Estado vacío con mensaje apropiado
- Indicador de última actualización

### 7. **printer-modal.js** (28 KB)
Modal detallado de control individual:
- **5 Tabs**: Control, Archivos, Historial, Estadísticas, Logs
- **Tab Control**:
  - Progreso en tiempo real
  - Sliders de temperatura (hotend y cama)
  - Controles rápidos (pause, resume, cancel, home, emergency)
  - Control manual de ejes
  - Slider de velocidad
  - Gcode personalizado
- **Tab Archivos**:
  - Upload de archivos
  - Lista de archivos disponibles
  - Enviar a imprimir
- **Tab Historial**: Comandos ejecutados
- **Tab Estadísticas**: Trabajos completados, tiempo total, tasa de éxito
- **Tab Logs**: Log de auditoría
- Auto-refresh cada 5 segundos (solo en tab control)
- Responsive y accesible (cierre con ESC)

### 8. **files.js** (13 KB)
Gestor de archivos gcode:
- Lista de archivos en tabla
- Información: nombre, tamaño, usuario, fecha, privacidad
- Upload con validación (tipo y tamaño)
- Drag & drop ready
- Acciones:
  - Enviar a imprimir (con modal de selección de impresora)
  - Descargar
  - Cambiar privacidad (privado/público)
  - Eliminar
- Filtros y búsqueda
- Estadísticas de archivos
- Estado vacío

### 9. **statistics.js** (11 KB)
Gestor de estadísticas:
- **Overview**: 4 stat cards principales
  - Total impresoras activas
  - Trabajos completados
  - Horas totales de impresión
  - Tasa de éxito
- **Top Printers**: Ranking con medallas
- **Reporte de uso**: Por período (7d, 30d, 90d, all)
- **Historial de trabajos**: Tabla completa
- **Uso de filamento**: Gráficos
- Selector de períodos
- Botón de refresh

### 10. **admin.js** (19 KB)
Panel de administración completo:
- **Sistema de tabs**: users, printers, groups, stats, logs
- **Gestión de Usuarios**:
  - Lista en tabla con avatar
  - Crear, editar, eliminar
  - Bloquear/desbloquear
  - Asignar impresoras
  - Asignar rol (admin/user)
  - Permisos de impresión privada
- **Gestión de Impresoras**:
  - Cards con información
  - Crear, editar, eliminar
  - Configurar visibilidad (público/privado)
  - Ver última actividad
- **Gestión de Grupos**:
  - Cards de grupos
  - Crear, editar, eliminar
  - Agregar/remover miembros
- **Estadísticas**: Integración con StatisticsManager
- **Logs de auditoría**: Tabla con filtros
- Modales para todas las acciones
- Validaciones y confirmaciones

### 11. **app.js** (13 KB)
Inicialización principal de la aplicación:
- Detección automática de página
- Inicialización específica por página:
  - **Auth**: Manejo de login/register con validaciones
  - **Dashboard**: PrintersManager + estadísticas
  - **Admin**: AdminManager (requiere rol admin)
  - **Files**: FilesManager
  - **Statistics**: StatisticsManager completo
- Eventos globales:
  - Online/offline detection
  - Atajos de teclado (Ctrl+K búsqueda, Ctrl+R refresh)
  - Advertencia antes de cerrar si hay impresiones
- Password strength indicator
- Toggle password visibility
- FAB button handler
- Debug mode con helpers en consola
- Error handling global
- Banner de consola con estilo

## Características Destacadas

### 🎯 Arquitectura
- Clases modulares y reutilizables
- Separación de responsabilidades
- API client centralizado
- Sistema de eventos
- Manejo de errores consistente

### 🔄 Auto-refresh Inteligente
- Intervalos configurables
- Pausa cuando tab no está visible
- Indicador de última actualización
- Diferentes velocidades según estado

### 🔐 Seguridad
- Tokens en localStorage
- Validación de sesión periódica
- Logout automático si sesión expira
- Protección de rutas según rol
- Validación de permisos

### 🎨 UX/UI
- Notificaciones toast elegantes
- Confirmaciones antes de acciones destructivas
- Loading states
- Estados vacíos informativos
- Modales accesibles (ESC para cerrar)
- Atajos de teclado

### 📱 Responsive
- Detección de móvil
- Adaptación de layouts
- Touch-friendly

### 🐛 Debug Mode
- Logging condicional
- Helpers en consola
- Inspección de estado
- Testing facilitado

## Flujo de la Aplicación

```
1. app.js detecta la página actual
2. Verifica autenticación si es necesario
3. Inicializa el manager correspondiente:
   - Dashboard → PrintersManager
   - Admin → AdminManager  
   - Files → FilesManager
   - Statistics → StatisticsManager
4. Los managers cargan datos vía API client
5. Renderización de UI
6. Auto-refresh si aplica
7. Event listeners para interacciones
```

## Orden de Carga en HTML

```html
<!-- Configuración y utilidades base -->
<script src="js/config.js"></script>
<script src="js/utils.js"></script>

<!-- API y autenticación -->
<script src="js/api.js"></script>
<script src="js/auth.js"></script>

<!-- Componentes UI -->
<script src="js/notifications.js"></script>

<!-- Managers específicos (cargar según página) -->
<script src="js/printers.js"></script>
<script src="js/printer-modal.js"></script>
<script src="js/files.js"></script>
<script src="js/statistics.js"></script>
<script src="js/admin.js"></script>

<!-- Inicialización (siempre último) -->
<script src="js/app.js"></script>
```

## Dependencias entre Módulos

```
app.js
  ├─ auth.js
  │   ├─ api.js
  │   │   ├─ config.js
  │   │   └─ utils.js
  │   ├─ notifications.js
  │   └─ utils.js
  ├─ printers.js
  │   ├─ api.js
  │   ├─ printer-modal.js
  │   ├─ notifications.js
  │   └─ utils.js
  ├─ files.js
  │   ├─ api.js
  │   ├─ notifications.js
  │   └─ utils.js
  ├─ statistics.js
  │   ├─ api.js
  │   ├─ notifications.js
  │   └─ utils.js
  └─ admin.js
      ├─ api.js
      ├─ notifications.js
      ├─ statistics.js
      └─ utils.js
```

## Variables Globales Expuestas

```javascript
window.app              // Instancia principal
window.printersManager  // Gestor de impresoras (dashboard)
window.filesManager     // Gestor de archivos
window.adminManager     // Gestor admin
window.PrinterModal     // Clase del modal de impresora
window.debug            // Helpers de debug (solo si DEBUG=true)
```

## Debug Helpers

En modo desarrollo (`CONFIG.DEBUG = true`):

```javascript
// En la consola del navegador:
debug.auth.getUser()                    // Ver usuario actual
debug.notifications.success("Test")    // Probar notificación
debug.api.getPrinters()                 // Llamar API directamente
debug.config                            // Ver configuración
debug.utils.formatBytes(1024000)       // Usar utilidades
```

## Próximos Pasos

Con JavaScript completo, continuamos con:

1. ✅ **CSS Completado** (93 KB)
2. ✅ **JavaScript Completado** (137 KB)
3. ⏳ **HTML pages** (login, register, dashboard, admin, files, statistics)
4. ⏳ **Integration & Testing**

---

**Total: 11 archivos JavaScript | 137 KB | Arquitectura modular completa** 🚀✨
