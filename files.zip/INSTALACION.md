# 🚀 Guía de Instalación y Deployment - PrinterHub Frontend

## 📋 Requisitos Previos

- Servidor web (Apache, Nginx, etc.)
- PHP 7.4+ (para el backend)
- Navegador moderno (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+)

## 📦 Instalación

### Opción 1: Apache

```bash
# 1. Copiar archivos al directorio web
sudo cp -r printerhub-frontend/* /var/www/html/

# 2. Establecer permisos
sudo chown -R www-data:www-data /var/www/html/
sudo chmod -R 755 /var/www/html/

# 3. Reiniciar Apache
sudo systemctl restart apache2

# 4. Acceder desde el navegador
# http://tu-servidor/
```

### Opción 2: Nginx

```bash
# 1. Copiar archivos al directorio web
sudo cp -r printerhub-frontend/* /usr/share/nginx/html/

# 2. Establecer permisos
sudo chown -R nginx:nginx /usr/share/nginx/html/
sudo chmod -R 755 /usr/share/nginx/html/

# 3. Reiniciar Nginx
sudo systemctl restart nginx

# 4. Acceder desde el navegador
# http://tu-servidor/
```

### Opción 3: Servidor de desarrollo (solo testing)

```bash
# Python 3
cd printerhub-frontend
python3 -m http.server 8000

# PHP
cd printerhub-frontend
php -S localhost:8000

# Node.js (requiere npx)
cd printerhub-frontend
npx serve

# Acceder a http://localhost:8000
```

## ⚙️ Configuración

### 1. Configurar URL de la API

Editar `js/config.js`:

```javascript
const CONFIG = {
  API_URL: '/api',  // Cambiar a la URL de tu backend
  // Ejemplo: API_URL: 'https://api.printerhub.com'
  // ...resto de configuración
};
```

### 2. Ajustar intervalos de actualización (opcional)

En `js/config.js`:

```javascript
REFRESH_INTERVAL: 5000,        // Actualización normal (5 segundos)
REFRESH_INTERVAL_FAST: 2000,   // Cuando está imprimiendo (2 segundos)
REFRESH_INTERVAL_SLOW: 10000,  // Cuando está idle (10 segundos)
```

### 3. Personalizar colores (opcional)

Editar `styles/variables.css`:

```css
:root {
  --primary: #9333ea;     /* Púrpura - Color principal */
  --secondary: #ec4899;   /* Rosa - Color secundario */
  --accent: #06b6d4;      /* Cyan - Color de acento */
  /* Modificar según tu branding */
}
```

### 4. Configurar límites de archivos (opcional)

En `js/config.js`:

```javascript
MAX_FILE_SIZE: 100 * 1024 * 1024,  // 100 MB
ALLOWED_FILE_TYPES: ['.gcode', '.gco', '.g'],
```

## 🌐 Configuración de Apache

### Virtual Host básico

Crear `/etc/apache2/sites-available/printerhub.conf`:

```apache
<VirtualHost *:80>
    ServerName printerhub.local
    DocumentRoot /var/www/html

    <Directory /var/www/html>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
        
        # Habilitar rewrite para SPA routing (si se necesita)
        RewriteEngine On
        RewriteBase /
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule . /index.html [L]
    </Directory>

    # Configuración de logs
    ErrorLog ${APACHE_LOG_DIR}/printerhub_error.log
    CustomLog ${APACHE_LOG_DIR}/printerhub_access.log combined
</VirtualHost>
```

Habilitar el sitio:

```bash
sudo a2ensite printerhub.conf
sudo a2enmod rewrite
sudo systemctl restart apache2
```

### HTTPS con SSL (Recomendado para producción)

```apache
<VirtualHost *:443>
    ServerName printerhub.com
    DocumentRoot /var/www/html

    SSLEngine on
    SSLCertificateFile /path/to/cert.pem
    SSLCertificateKeyFile /path/to/key.pem
    
    <Directory /var/www/html>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>

# Redireccionar HTTP a HTTPS
<VirtualHost *:80>
    ServerName printerhub.com
    Redirect permanent / https://printerhub.com/
</VirtualHost>
```

## 🌐 Configuración de Nginx

### Server block básico

Crear `/etc/nginx/sites-available/printerhub`:

```nginx
server {
    listen 80;
    server_name printerhub.local;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache para archivos estáticos
    location ~* \.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Logs
    access_log /var/log/nginx/printerhub_access.log;
    error_log /var/log/nginx/printerhub_error.log;
}
```

Habilitar el sitio:

```bash
sudo ln -s /etc/nginx/sites-available/printerhub /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### HTTPS con SSL (Recomendado para producción)

```nginx
server {
    listen 443 ssl http2;
    server_name printerhub.com;
    root /usr/share/nginx/html;
    index index.html;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    # Configuración SSL moderna
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    
    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~* \.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}

# Redireccionar HTTP a HTTPS
server {
    listen 80;
    server_name printerhub.com;
    return 301 https://$server_name$request_uri;
}
```

## 🐳 Deployment con Docker

### Dockerfile

```dockerfile
FROM nginx:alpine

# Copiar archivos del frontend
COPY . /usr/share/nginx/html/

# Copiar configuración de nginx (opcional)
# COPY nginx.conf /etc/nginx/nginx.conf

# Exponer puerto
EXPOSE 80

# Comando de inicio
CMD ["nginx", "-g", "daemon off;"]
```

### docker-compose.yml

```yaml
version: '3.8'

services:
  frontend:
    build: .
    ports:
      - "80:80"
    volumes:
      - ./:/usr/share/nginx/html/
    restart: always
```

### Comandos

```bash
# Build
docker build -t printerhub-frontend .

# Run
docker run -d -p 80:80 --name printerhub printerhub-frontend

# Con docker-compose
docker-compose up -d
```

## 🔒 Seguridad

### 1. Configurar HTTPS

- Obtener certificado SSL (Let's Encrypt gratis)
- Forzar redirección HTTP → HTTPS
- Habilitar HSTS

```apache
# Apache
Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
```

```nginx
# Nginx
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
```

### 2. Configurar Content Security Policy

```apache
# Apache
Header set Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';"
```

```nginx
# Nginx
add_header Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';";
```

### 3. Protección XSS

```apache
# Apache
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "SAMEORIGIN"
Header set X-XSS-Protection "1; mode=block"
```

```nginx
# Nginx
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
```

## ⚡ Optimización

### 1. Comprimir archivos (gzip)

**Apache:**
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/css text/javascript application/javascript
</IfModule>
```

**Nginx:**
```nginx
gzip on;
gzip_vary on;
gzip_types text/css text/javascript application/javascript;
```

### 2. Cache de archivos estáticos

Ya incluido en las configuraciones de ejemplo arriba.

### 3. Minificar CSS y JS (opcional)

```bash
# Instalar herramientas
npm install -g terser clean-css-cli

# Minificar JS
terser js/app.js -o js/app.min.js

# Minificar CSS
cleancss styles/main.css -o styles/main.min.css
```

## 🧪 Testing

### Verificar instalación

1. Acceder a http://tu-servidor/
2. Debe mostrar el landing page
3. Click en "Iniciar Sesión"
4. Debe cargar la página de login
5. Verificar en consola del navegador (F12) que no hay errores

### Testing de API

Abrir consola del navegador:

```javascript
// Verificar configuración
console.log(CONFIG);

// Test de conexión (sin backend funcionará con error esperado)
debug.api.getPrinters().then(console.log).catch(console.error);
```

## 🐛 Troubleshooting

### Problema: Archivos CSS/JS no cargan

**Solución:** Verificar permisos y rutas:

```bash
sudo chmod -R 755 /var/www/html/
# Verificar en navegador (F12 → Network) qué archivos fallan
```

### Problema: Error CORS al conectar con API

**Solución:** Configurar CORS en el backend o usar proxy:

```nginx
# Nginx como proxy
location /api/ {
    proxy_pass http://backend:3000/;
    add_header Access-Control-Allow-Origin *;
}
```

### Problema: "404 Not Found" en páginas

**Solución:** Verificar que el mod_rewrite (Apache) o try_files (Nginx) esté configurado.

## 📊 Monitoreo

### Logs de acceso

```bash
# Apache
tail -f /var/log/apache2/printerhub_access.log

# Nginx
tail -f /var/log/nginx/printerhub_access.log
```

### Logs de errores

```bash
# Apache
tail -f /var/log/apache2/printerhub_error.log

# Nginx
tail -f /var/log/nginx/printerhub_error.log
```

## 🔄 Actualización

```bash
# 1. Backup
sudo cp -r /var/www/html/ /var/www/html.backup

# 2. Copiar nuevos archivos
sudo cp -r printerhub-frontend-new/* /var/www/html/

# 3. Limpiar cache del navegador (Ctrl + Shift + R)
```

## 📞 Soporte

Si tienes problemas con la instalación:

1. Revisa los logs del servidor
2. Verifica la consola del navegador (F12)
3. Asegúrate de que la API esté configurada correctamente
4. Consulta la documentación completa

---

**¡Listo!** Tu PrinterHub frontend está instalado y funcionando. 🎉
